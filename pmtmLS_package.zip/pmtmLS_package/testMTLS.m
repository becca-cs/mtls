%% Check that the MTLS produces the same results as the normal MT for a regularly sampled timeseries
clear; close all; 
pathnm = '/Users/rcs/Documents/MATLAB/pmtmLS_package';
addpath(genpath(pathnm))

% parameters for multitaper estimation
nw = 3; % number of windows (should choose a value that produces good agreement 
% with true spectral behavior on the frequencies of interest in synthetic data)

% Generate a timeseries
N = 10000; % max year
delt = 1.0; % timesteps
t0 = 0; % starting time
ntp = N+1; % total number of timeseps
delta_f = 1/N; % Sampling frequency (Hz)
f = (delta_f:delta_f:ntp/2/N)'; % frequency vector
nu = 0.5; sigbdot = 1; % m/yr
Pmax = 2*delt*sigbdot^2; fmax = f(end);
PSD = Pmax.*(f./fmax).^-nu;
x = generate_timeseries(PSD,N);
% check that the variance in the generate timeseries = variance in PSD
% there's a weird offset between the "true" spectrum and
% the spectrum estimated by the multitaper - has to do with the
% normalization scheme
disp(['var in timeseries = ' num2str(round(var(x)))])
disp(['var in psd = ' num2str(round(var(x)))])

tt = 0:delt:N; % evenly sampled timesteps

% compute MTLS and MT
figure();
[Pls,sls] = pmtmLS(x,tt,nw,0);  %MTLS
[P,s] = pmtmPH(x,delt,nw,0); %MT
plot(sls,Pls,'k'); hold on;
plot(s,P,':k','linewidth',2);
plot(s, (s./s(end)).^-nu, '-r','linewidth',2)
set(gca,'yscale','log','xscale','log')

legend('MTLS','MT',['true spectrum (\beta = ' num2str(nu) ')'],...
    'location','southwest')
set(gca,'fontsize',12); xlabel('frequency (1/yr)'); ylabel('spectral density (^oC / yr)')
grid on;

%% test the MTLS on an unevenly sampled timeseries
clear; close all; addpath(genpath('multitaper_LS'))
addpath(genpath('/Users/rcs/Documents/MATLAB/Variability/functionsPH'))

N = 10000; % time length;
Ns = 7000; % number of uneven samples
nw = 8; % number of windows

delt = 1.0; % time difference
t0 = 0; % starting time

nts=floor((N-t0)/delt) +1; %number of time steps ('round' used because need nts as integer)
nyrs = N-t0; ntp = N+1;

delta_f = 1/N; % Sampling frequency (Hz)
f = (1/N:1/N:ntp/2/N)'; % frequency vector
nu = 1; sigbdot = 1; % m/yr
Pmax = 2*delt*sigbdot^2; fmax = f(end);
PSD = Pmax.*(f./fmax).^-nu;

x = generate_timeseries(PSD,N);

tt = 0:delt:N; tt = tt(:);
ts = randsample(tt,Ns); ts = sort(ts);
xs = interp1(tt,x,ts);
t = linspace(0,N,Ns); % even timesteps
dt = (t(end)-t(1))./length(t); % length of even timesteps

figure(1)
plot(tt(1:1000),x(1:1000)); hold on;
scatter(ts,xs); xlim([0 1000])

figure(2);
ind = ~isnan(xs) & ~isnan(ts); 
[Pls,sls] = pmtmLS(xs(ind),ts(ind),nw,0); 
% biases in the lowest frequencies, so cut off the last few frequencies
plot(sls(4:end),Pls(4:end),'k'); hold on;
set(gca,'yscale','log','xscale','log')

% try normal MT, with interpolation
ti = linspace(t0,N,Ns);
xi = interp1(ts,xs,ti);
ind = ~isnan(ti) & ~isnan(xi);
[P,s] = pmtmPH(xi(ind),dt,nw,0);
plot(s(4:end),P(4:end),':k','linewidth',2);
plot(s, (s./s(end)).^-nu, '-r','linewidth',2)

legend('MTLS','MT',['true spectrum (\beta = ' num2str(nu) ')'],...
    'location','southwest')
set(gca,'fontsize',12); xlabel('frequency (1/yr)'); ylabel('spectral density (^oC / yr)')
grid on;