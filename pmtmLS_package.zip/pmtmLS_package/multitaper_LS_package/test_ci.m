function [p,chi] = test_ci(v)

p = linspace(0.000002,0.999998);

g = log ( gamma ( v / 2 ) );

for i = 1:length(p)
    for j = 1:length(v)
        [chi(i,j), ifault(i,j)] = ppchi2(p(i),v(j),g(j));
    end
end

end

